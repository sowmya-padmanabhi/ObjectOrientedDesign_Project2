#pragma once
///////////////////////////////////////////////////////////////////////
// Browse.h - allows the browsing of files in NoSqlDb                //
// ver 1.0                                                           //
// Sowmya Padmanabhi                                                 //
///////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  The following functionalities are provided by this package: querying files, viewing files and checking 
*  dependencies for the NoSqlDb.
*
*  Required Files:
*  ---------------
*  Browse.h
*  DbCore.h
*  PayLoad.h
*  Query.h
*  GraphWalk.h
*  Process.h
*
*  Maintenance History:
*  --------------------
*  Ver 1.0 : 2 Mar 2018
*  - first release
*/
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>
#include "../Query/Query.h"
#include "../DbCore/DbCore.h"
#include "../Process/Process.h"
#include "../GraphWalk/GraphWalk.h"
#include "../PayLoad/PayLoad.h"

using namespace NoSqlDb;

template <typename P>
class Browse
{
private:
	using Graph = Graph<std::string>;
	using Node = Node<std::string>;
	using Sptr = GraphProcessing::Sptr<std::string>;
	Keys keys_;
	DbCore<P> db_;
	Process p;
	Graph g;
	std::queue<std::string> q;
	bool flag = true;

public:
	static void identify(std::ostream& out = std::cout);
	Browse& queryKeys(const std::string regExp);
	Browse& queryDependency(const std::string regExp);
	void show(std::ostream& out = std::cout);
	void buildDependency(const Key& key);
	void openDependency(const Key& key);
	bool getOpenDependency(const Key& key);
	void showDependency(const Key& key);
	void showFile(Key key, std::string filePath);
	Keys& keys() { return keys_; }
	Browse(DbCore<P>& db) {
		db_ = db;
	}

};
template<typename P>
Browse<P>& Browse<P>::queryKeys(const std::string regExp)
{
	Query<P> q(db_);
	keys_ = q.selectKeys(regExp).keys();
	for (Key k : keys_) {
		std::cout << "These are the dependencies for the key " << k << std::endl;
		queryDependency(k);
	}
	return *this;
}

//Gets the dependencies of the key
template<typename P>
Browse<P>& Browse<P>::queryDependency(const std::string regExp)
{
	DbElement<P> e = db_[regExp];
	Children children = e.children();
	if (children.size() > 0)
	{
		for (Key k : e.children()) {
			keys_.push_back(k);
			std::cout << k << "\n";
		}
	}
	else std::cout << "\n\n No child keys.\n";
	return *this;
}

//Provides records for the keys that are queried in the class' method.
template<typename P>
void Browse<P>::show(std::ostream & out)
{
	showHeader();
	for (Key k : keys_) {
		DbElement<P> temp = db_[k];
		showRecord(k, temp);
	}
}

//Using GraphWalk, there are reursive calls for building dependency graph.
template<typename P>
void Browse<P>::buildDependency(const Key & key)
{
	keys_.clear();
	queryDependency(key);
	if (keys_.size() > 0) {
		for (Key k : keys_) {
			q.push(k);
			g.addNode(Sptr(new Node(k)));
			g.addEdge(key, k);
		}
	}

		q.pop();
		if(!q.empty())
			buildDependency(q.front());
}

//Uses GraphWalk for building and displaying the dependencies
template<typename P>
void Browse<P>::showDependency(const Key & key)
{
	q.push(key);
	g.addNode(Sptr(new Node(key)));
	buildDependency(key);
	showGraph(g);
}

//Checks the status of the dependent files to see if they are open.
template<typename P>
void Browse<P>::openDependency(const Key & key)
{
	keys_.clear();
	queryDependency(key);
	if (keys_.size() > 0) {
		for (Key k : keys_) {
			q.push(k);
			DbElement<P> e = db_[k];
			std::cout << "\nName of key is " << e.name() << "\n";
			PayLoad p = e.payLoad();
			if (p.status() != "" && p.status() == "open") {
				std::cout << "\nDependent key " << k << " has open status!\n";
				flag = false;
			}
		}
	}

	q.pop();
	if (!q.empty())
		openDependency(q.front());
}

//Recursive function is called to see if the file status is open.
template<typename P>
bool Browse<P>::getOpenDependency(const Key & key)
{
	q.push(key);
	openDependency(key);
	return flag;
}

//Allows people to view the file
template<typename P>
void Browse<P>::showFile(Key key, std::string filePath)
{
	std::string appPath = "c:/windows/system32/notepad.exe";
	p.application(appPath);

	std::string cmdLine = "/A " + filePath + key;
	p.commandLine(cmdLine);

	std::cout << "\n  Start of the process: \"" << appPath << "\"";
	std::cout << "\n  with this commandLine: \"" << cmdLine << "\"";
	p.create();

	CBP callback = []() { std::cout << "\n ----Exiting of the child process here ---"; };
	p.setCallBackProcessing(callback);
	p.registerCallback();

	std::cout << "\n After the 'OnExit' ";
	std::cout.flush();
	char ch;
	std::cout << "\nPlease press the enter key\n";
	std::cin.read(&ch, 1);
}

//Prints path of package
template<typename P>
void Browse<P>::identify(std::ostream& out)
{
	out << "\n  \"" << __FILE__ << "\"";
}
