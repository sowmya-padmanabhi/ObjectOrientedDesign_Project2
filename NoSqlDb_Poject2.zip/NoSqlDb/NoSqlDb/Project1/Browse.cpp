/////////////////////////////////////////////////////////////////////
// Browse.cpp - allows browsing of files in NoSQLDB                //
// ver 1.0                                                         //
// Sowmya Padmanabhi                                                //
/////////////////////////////////////////////////////////////////////

#include "Browse.h"
#include "../PayLoad/PayLoad.h"

#ifdef TEST_BROWSE

//Adding data to DbCore instance
bool testR3a(DbCore<PayLoad>& db)
{
	DbElement<PayLoad> demoElem;

	demoElem.name("Jim");
	demoElem.descrip("Instructor for CSE687");
	demoElem.dateTime(DateTime().now());
	demoElem.payLoad(PayLoad("The good news is ..."));

	if (demoElem.name() != "Jim")
		return false;
	if (demoElem.descrip() != "Instructor for CSE687")
		return false;
	if (demoElem.dateTime().now() != DateTime().now())
		return false;
	if (std::string(demoElem.payLoad()) != std::string("The good news is ..."))
		return false;

	db["FileNameSpace::Fawcett.cpp::3"] = demoElem;
	return true;
}

//Adding data to DbCore instance
bool testR3b(DbCore<PayLoad>& db)
{
	DbElement<PayLoad> demoElem = db["FileNameSpace::Fawcett.cpp::3"];

	demoElem.name("Ammar");
	demoElem.descrip("TA for CSE687");
	demoElem.payLoad(PayLoad("You should try ..."));
	db["NameSpace::Salman.java::1"] = demoElem;
	if (!db.contains("NameSpace::Salman.java::1"))
		return false;

	demoElem.name("Jianan");
	demoElem.payLoad(PayLoad("Dr. Fawcett said ..."));
	db["Sal"] = demoElem;

	demoElem.payLoad(PayLoad("You didn't demonstrate Requirement #4"));
	demoElem.name("Nikhil");
	db["Prashar"] = demoElem;

	PayLoad p;
	p.value("../Files/");
	p.status("open");
	p.categories().push_back("category1");
	p.categories().push_back("category2");
	demoElem.payLoad(p);
	demoElem.name("Pranjul");
	db["FileNameSpace::Fawcett.hs::7"] = demoElem;

	Keys keys = db.keys();
	db["FileNameSpace::Fawcett.hs::7"].children().push_back("Sanman");
	db["FileNameSpace::Fawcett.hs::7"].children().push_back("Arora");

	demoElem = db["NameSpace::Salman.java::1"];
	db["NameSpace::Salman.java::1"].children().push_back("Sal");
	db["NameSpace::Salman.java::1"].children().push_back("Prashar");
	db["NameSpace::Salman.java::1"].children().push_back("FileNameSpace::Fawcett.hs::7");

	return true;
}

//Testing all functionlaties in Browse class
bool testLatestVersion(DbCore<PayLoad>& db) {
	
	Browse<PayLoad> b(db);
	b.showDependency("Namespace::Salman.java::1");

	return true;
}

int main() {
	DbCore<PayLoad> db;
	testR3a(db);
	testR3b(db);
	testLatestVersion(db);

	std::cin.get();

	return 0;
}

#endif // TEST_BROWSE
