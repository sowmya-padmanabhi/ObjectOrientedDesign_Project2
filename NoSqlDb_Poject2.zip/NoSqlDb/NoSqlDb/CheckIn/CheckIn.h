#pragma once
/////////////////////////////////////////////////////////////////////
// CheckIn.h - allows checking in of files                         //
// ver 1.0                                                         //
// Sowmya Padmanabhi                                                //
/////////////////////////////////////////////////////////////////////
/*
*  Package Operations:
*  -------------------
*  This package allows checking in of files i.e. changes to be made on latest version of file
*  for the NoSqlDb.
*
*  Required Files:
*  ---------------
*  Browse.h
*  DbCore.h
*  PayLoad.h
*  Query.h
*  Version.h
*
*  Maintenance History:
*  --------------------
*  Ver 1.0 : 2 Mar 2018
*  - first release
*/
#include <string>
#include <iostream>
#include "../DbCore/DbCore.h"
#include "../Query/Query.h"
#include "../Version/Version.h"
#include "../Project1/Browse.h"
#include "../PayLoad/PayLoad.h"
#include <fstream>
#include <Windows.h>
#include <stdlib.h>

using namespace NoSqlDb;

template <typename P>
class CheckIn
{
public:
	//Constructor:Inititalizing class with the latest instance of DbCore
	CheckIn(const DbCore<P>& db) { db_ = db; }

	static void identify(std::ostream& out = std::cout);

	//Gets open dependent file, if any.
	bool getOpenDependency() {
		Browse<P> b(db_);
		std::cout << "The Dependency status for the file is: " << b.getOpenDependency(currKey_) << "\n"; 
		return b.getOpenDependency(currKey_);
	}

	//Checks if the author is only checking the file or not.
	bool checkAuthor() {
		std::string auth = getAuthor();
		std::cout << "\nThe author for the latest file version is: " << auth << " and the author for the current file version is: " << dbe_.name() << "\n";
		if (auth != " " && dbe_.name() != " " && auth == dbe_.name())
			return true;
		else return false;
	}

	//Incremented file verison is added to the closed check-ins.
	bool addVersionToFile() {
		std::cout << "\n Adding the version to file\n";
		Version<P> v(db_);
		int version = v.latestVersion(key_);
		std::cout << "\n Printing the latest version of the file: " << version << "\n";
		currKey_ = key_ + "." + std::to_string(version);
		std::cout << "\nPrinting the current value of the key: " << currKey_ << "\n";
		std::string status = getStatus();
		std::cout << "\nPrinting the status:" << status << "\n";
		if(status != "" && status == "close")
			version += 1;
		newKey_ = key_ + "." + std::to_string(version);
		std::cout << "\nPrinting the Key after adding the version: " << newKey_ << "\n";
		if (key_ != "")
			return true;
		else return false;
	}

	//Getting the author of the file
	std::string getAuthor() {
		Query<P> q(db_);
		DbElement<P> e;
		Keys keys = q.selectKeys(key_).keys();
		if(keys.size() > 0)
			e = db_[keys.back()];
		std::cout << "\n\n e.name(): " << e.name() << "\n";
		return e.name();
	}

	//Gets the file path of the file that needs to be checked in
	std::string getFilePath() {
		PayLoad p;
		p = dbe_.payLoad();
		std::cout << "\nPrinting the file path: " << p.value() << "\n";
		return p.value();
	}

	//File moving from ClientRepo to its file path
	bool moveFile() {
		std::string src = "../ClientRepo/" + key_;
		std::string dst = getFilePath() + newKey_;

		std::cout << "\n Moving the file (from its source) " << src << " to the path (the destination) " << dst << "\n";

		std::ifstream in(src.c_str());
		std::ofstream out(dst.c_str());

		out << in.rdbuf();

		out.close();
		in.close();

		if (std::remove(src.c_str()) != 0)
			perror("Error: Error while deleting the file");
		else
			puts("Success: The File successfully deleted");

		return true;
	}

	//Checks if file exists in ClientRepo
	bool fileInFolder() {
		std::string filepath = "../ClientRepo/" + key_;
		std::cout << "\nThe path of the file to check if that file exists is: " << filepath << "\n";
		std::fstream file;
		file.open(filepath.c_str(), std::ios::in);
		if (file.is_open() == true)
		{
			std::cout << "\n The file exists in the folder\n";
			file.close();
			return true;
		}
		file.close();
		return false;
	}

	//Status of latest version of file
	std::string getStatus() {
		PayLoad p;
		Query<P> q(db_);
		//std::cout << "\n Searching with key " << key_ << "\n";
		Keys keys = q.selectKeys(key_).keys();
		DbElement<P> e;
		if(keys.size() > 0)
			e = db_[keys.back()];
		p = e.payLoad();
		std::cout << "\nStatus of the file is: " << p.status() << "\n";
		return p.status();
	}

	//Allowing the users to make changes in the file.
	bool editFile() {
		Browse<P> b(db_);
		b.showFile(key_, "../ClientRepo/");
		return true;
	}

	//Calling all the above methods to perform check-in
	bool checkInFile(const Key& key, DbElement<P> dbe) { 
		std::cout << "\n----Inside the check-in file\n----";
		bool flag = false;
		key_ = key;
		dbe_ = dbe;
		std::string status = getStatus();
		
			if (status != "") {
			std::cout << "\n----Status: Inside status----\n";
			if (checkAuthor()) {
			std::cout << "\n----checkAuthor: check author----\n";
			if (fileInFolder()) {
			std::cout << "\n----fileInFolder: Inside file in folder----\n";
			if (addVersionToFile()) {
			std::cout << "\n----addVersionToFile: Inside add version to file----\n";
			if (getOpenDependency()) {
			std::cout << "\n----getOpenDependency: Inside check status of dependent files----\n";
			if (editFile()) {
			std::cout << "\n----editFile: Inside edit file----\n";
			if (moveFile()) {
			db_[newKey_] = dbe_;
			flag = true;
			}
			}
			}
			}
			}
			}
			}
		else std::cout << "\n\n Warning:Please make sure to close the files before checking in the current file. Either the file status was not received or the dependent files were open. \n"; 
		showDb(db_);
		return flag;
	}

private:
	Key key_;
	Key currKey_;
	Key newKey_;
	DbCore<P> db_;
	DbElement<P> dbe_;
};

template<typename P>
void CheckIn<P>::identify(std::ostream & out)
{
	out << "\n  \"" << __FILE__ << "\"";
}
