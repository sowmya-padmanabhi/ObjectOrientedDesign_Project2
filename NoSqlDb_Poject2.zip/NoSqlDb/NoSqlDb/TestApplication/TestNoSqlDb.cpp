///////////////////////////////////////////////////////////////////////
// TestNoSqlDb.cpp - test file for Test package                      //
// ver 1.0                                                           //
// Author : Sowmya Padmanabhi                                         //
///////////////////////////////////////////////////////////////////////

#include "TestNoSqlDb.h"

#ifdef TEST_TESTNOSQLDB

using namespace Utilities;

//----Main method to test Test package----
int main()
{
	Utilities::Title("Testing: Testing the DbCore - He said, she said database");
	putLine();

	return 0;
}
#endif
