///////////////////////////////////////////////////////////////////////
// TestApplication.cpp - designed to test deployment strategy        //
// ver 1.0                                                           //
// Jim Fawcett, CSE687 - Object Oriented Design, Spring 2018         //
///////////////////////////////////////////////////////////////////////
/*
* - This shows an example where the NoSqlDb functionalities are used by the applications.
* - Needs to do the following:
*   - Copy NoSqlDb folder into solution directory
*   - The libraries referenced below takes care of the NoSqlDb packages thats needed.
*   - Define PayLoad package
*   - Include its NoSqlDb.h header
*   - Include its PayLoad.h
*   - Make reference to the Executive.lib
*/
#include "../Executive/NoSqlDb.h"
#include "../PayLoad/PayLoad.h"

using namespace NoSqlDb;
// This demo code was simply used from Executive.cpp
int main()
{
  Utilities::Title("Demonstartion of the working of deployment strategy: TestApplication");
  Utilities::putline();

  Utilities::title("Making of the demonstration database");
  DbCore<PayLoad> db;

  DbElement<PayLoad> elem = makeElement<PayLoad>("Name", "Description");
  PayLoad pl;
  pl.value("Payload value");
  pl.categories().push_back("Some category");
  elem.payLoad(pl);
  db["first"] = elem;

  std::string name2 = "Different name";
  elem.name(name2);
  pl.value("\nDifferent payload value\n");
  pl.categories().push_back("\nDifferent category\n");
  elem.payLoad(pl);
  db["second"] = elem;

  showDb(db);
  Utilities::putline();

  elem.payLoad().showDb(db);
  Utilities::putline();

  Utilities::title("\nDemonstrating the Query\n");
  Query<PayLoad> q(db);
  q.select(
    [=](DbElement<PayLoad>& elem) {
    if (elem.name() == name2)
    {
      std::cout << "\n  " << elem.name();
      return true;
    }
    return false;
  }
  ).show();
  Utilities::putline();

  Utilities::title("Demonstration of the persistence to the XML String.");
  Persist<PayLoad> persist(db);
  std::string xml = persist.toXml();
  std::cout << xml;
  Utilities::putline();

  Utilities::title("Demonstration of the persistance to the db from XML string");
  persist.fromXml(xml);
  showDb(db);

  std::cout << "\n\n";
  return 0;
}

