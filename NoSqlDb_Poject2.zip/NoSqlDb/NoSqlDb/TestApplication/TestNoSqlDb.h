///////////////////////////////////////////////////////////////////////
// TestNoSqlDb.h - Contains tests for each requirement of solution   //
// ver 1.0                                                           //
// Author : Sowmya Padmanabhi                                         //
///////////////////////////////////////////////////////////////////////

/*
* Package Operations:
* -------------------
* Each requirement is tested in this package.
* Different packages are called and to execute each requirement.
*
* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* Utilities.h, Utilities.cpp
* Persistence.h
* Query.h
*
* Maintenance History:
* --------------------
* ver 1.0 : 5 Feb 2018
* - first release
*/

#pragma once
#include <iostream>
#include <iomanip>
#include <functional>
#include <unordered_map>
#include"../DbCore/DbCore.h"
#include"../Utilities/TestUtilities/TestUtilities.h"
#include"../Utilities/StringUtilities/StringUtilities.h"
#include "../PayLoad/PayLoad.h"
#include "../RepositoryCore/RepositoryCore.h"

using namespace NoSqlDb;

//----< number of characters to type are reduced.>----------------------

auto putLine = [](size_t n = 1, std::ostream& out = std::cout)
{
	Utilities::putline(n, out);
};

// DbProvider class
// -mechanism to test the database betweeb the test functions without passing the function argument.
class DbProvider
{
public:
	DbCore<PayLoad>& db() { return db_; }
private:
	static DbCore<PayLoad> db_;
};

DbCore<PayLoad> DbProvider::db_;

// test functions

inline void identity(std::ostream& out)
{
	out << "\n  \"" << __FILE__ << "\"";
}
//----< R1 >-----------------------------------------------------------
// Demonstrate that solution uses C++11

bool testR1()
{
	Utilities::title("Demonstration of the Requirement number 1");
	std::cout << "\n  " << typeid(std::function<bool()>).name()	<< ",are valid only for C++11 and versions after that.";
	return true; // would not compile unless C++11
}
//----< R2 >-----------------------------------------------------------

// Use of new and delete
bool testR2()
{
	Utilities::title("Demonstration of the Requirement number 2");
	std::cout << "\n  A visual examination of all the submitted code "
		<< "will show only the use of streams and operators new and delete.";
	return true;
}
//----< R3a >----------------------------------------------------------

//Demonstrate creation of DbElement
bool testR3a()
{
	DbCore<PayLoad> db_;
	DbProvider dbp;
	dbp.db() = db_;
	DbElement<PayLoad> demoElem;

	demoElem.name("Jim");
	demoElem.descrip("Instructor for CSE687");
	demoElem.dateTime(DateTime().now());
	PayLoad p;
	p.value("../Files/");
	p.categories().push_back("category1");
	p.categories().push_back("category2");
	p.status("open");
	demoElem.payLoad(p);

	if (demoElem.name() != "Jim")
		return false;
	if (demoElem.descrip() != "Instructor for CSE687")
		return false;
	if (demoElem.dateTime().now() != DateTime().now())
		return false;

	db_["name_space-SFileName.cpp.3"] = demoElem;
	dbp.db() = db_;
	return true;
}
//----< R3b >----------------------------------------------------------

// Demonstrate creation of Database
bool testR3b()
{
	DbProvider dbp;
	DbCore<PayLoad> db_ = dbp.db();

	DbElement<PayLoad> demoElem = db_["FileNameSpace-Fawcett.cpp.3"];

	PayLoad p;
	p.value("../Files/");
	p.categories().push_back("category1");
	p.categories().push_back("category2");
	p.status("open");
	demoElem.payLoad(p);

	demoElem.name("Ammar");
	demoElem.descrip("TA for CSE687");
	demoElem.payLoad().status("close");
	db_["Namespace-Salman.cpp.1"] = demoElem;

	demoElem.name("Jianan");
	demoElem.payLoad().status("close");
	db_["Sal.cpp.1"] = demoElem;

	demoElem.name("Nikhil");
	demoElem.payLoad().status("close");
	db_["Prashar.cpp.1"] = demoElem;

	demoElem.name("Pranjul");
	demoElem.payLoad().status("open");
	db_["FileNameSpace-Fawcett.cpp.4"] = demoElem;

	Keys keys = db_.keys();
	db_["FileNameSpace-Fawcett.cpp.4"].children().push_back("Prashar.cpp.1");

	demoElem = db_["Namespace-Salman.cpp.1"];
	db_["Namespace-Salman.cpp.1"].children().push_back("Sal.cpp.1");
	db_["Namespace-Salman.cpp.1"].children().push_back("FileNameSpace-Fawcett.cpp.4");
	showDb(db_);
	dbp.db() = db_;

	return true;
}

//----< R3 >----------------------------------------------------------
//Demonstrating use of all the required packages
bool myTest3()
{
	Utilities::Title("Demonstration of the Requirement number 3 - 'All the Required packages'");
	repoCoreTest3();
	return true;
}

//----< R7 >----------------------------------------------------------

// Demonstrating the use of the Executive package
bool testR12()
{
	Utilities::Title("Demonstration of the Requirement number 7 - 'The Executive Package'");
	std::cout << "\n  This is where you will find the executive package: ../Executive";
	Utilities::putline();
	std::cout << "\nThe Executive calls the TestExecutive class: ";
	identity(std::cout);
	std::cout << "\n  For the demonstration of the deployable structure, I use the Executive.";

	return true;
}

//----< R4 >----------------------------------------------------------
//Demonstrating the Check-in and Check-out of file
bool myTest4()
{
	DbProvider dbp;
	DbCore<PayLoad> db_ = dbp.db();
	Utilities::Title("Demonstration of the Requirement number 4  - 'Check-in and Check-out of the file'");
	repoCoreTest4(db_);
	dbp.db() = db_;
	return true;
}

//----< R5 >----------------------------------------------------------
// Demonstrate browsing of files
bool myTest5()
{
	DbProvider dbp;
	DbCore<PayLoad> db_ = dbp.db();
	Utilities::Title("Demonstration of the Requirement number 5 - 'Browse files'");
	repoCoreTest5(db_);
	dbp.db() = db_;
	return true;
}

//----< R6 >----------------------------------------------------------
//Demonstrate submitting of project with some closed check-ins and some open

bool myTest6()
{
	DbProvider dbp;
	DbCore<PayLoad> db_ = dbp.db();
	Utilities::Title("Demonstration of the Requirement number 6 - Some open Check-ins and some Closed Check-ins");
	std::cout << "\n\n Open or close status for each file is displayed in the Payload status.\n";
	showStatus(db_);
	dbp.db() = db_;
	return true;
}
//----< test stub >----------------------------------------------------
