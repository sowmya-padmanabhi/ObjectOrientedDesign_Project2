#pragma once
///////////////////////////////////////////////////////////////////////////
// RepositoryCore.h - test file for newly added Project 2 functionlity   //
// ver 1.0                                                               //
// Author : Sowmya Padmanabhi                                             //
///////////////////////////////////////////////////////////////////////////

/*
* Package Operations:
* -------------------
* This package contains tests for each requirement.
* It calls the different packages mentioned below to execute requirement.
*
* Required Files:
* ---------------
* DbCore.h
* Checkout.h
* CheckIn.h
*
* Maintenance History:
* --------------------
* ver 1.0 : 9 Mar 2018
* - first release
*/
#include "../DbCore/DbCore.h"
#include "../CheckIn/CheckIn.h"
#include "../CheckOut/Checkout.h"

void identify(std::ostream & out)
{
	out << "\n  \"" << __FILE__ << "\"";
}

bool repoCoreTest3() {
	identify(std::cout);
	CheckIn<PayLoad>::identify();
	Checkout<PayLoad>::identify();
	Version<PayLoad>::identify();
	Browse<PayLoad>::identify();
	return true;
}


bool repoCoreTestCheckOut(DbCore<PayLoad>& db_) {
	Checkout<PayLoad> co(db_);
	co.checkOutFile("Namespace-Salman.cpp.1", "../ClientRepo/");
	std::cout << "\nPlease check the ClientRepo folder to ensure that files have been copied!\n";
	std::cout.flush();
	char ch;
	std::cin.read(&ch, 1);
	return true;
}

bool repoCoreTest4(DbCore<PayLoad>& db_) {
	repoCoreTestCheckOut(db_);
	CheckIn<PayLoad> c(db_);
	DbElement<PayLoad> demoElem = db_["FileNameSpace-Fawcett.cpp.4"];
	demoElem.name("Pranjul");
	demoElem.descrip("Student of CSE687");
	PayLoad p;
	p.value("../Files/");
	p.status("close");
	p.categories().push_back("category1");
	p.categories().push_back("category2");
	demoElem.payLoad(p);
	bool res = c.checkInFile("FileNameSpace-Fawcett.cpp", demoElem);
	std::cout << "\nThe result is: " << res << "\n";
	return true;
}

bool repoCoreTest5(DbCore<PayLoad>& db_) {
	Browse<PayLoad> b(db_);
	std::cout << "\nBrowsing files with name \"FileNameSpace-Fawcett.cpp\"" << "\n";
	b.queryKeys("FileNameSpace-Fawcett.cpp").show();
	std::cout << "\n";
	std::cout << "\nShowing file FileNameSpace-Fawcett.cpp\n";
	b.showFile("NameSpace-Salman.cpp", "../ClientRepo/");
	std::cout << "\n";
	std::cout << "\nPrinting dependency graph for file \"Namespace-Salman.cpp.1\" and its related dependencies\n";
	b.showDependency("Namespace-Salman.cpp.1");
	return true;
}