///////////////////////////////////////////////////////////////////////////
// RepositoryCore.cpp - test file for newly added Project 2 functionlity //
// ver 1.0                                                               //
// Author : Sowmya Padmanabhi                                             //
///////////////////////////////////////////////////////////////////////////
#include "RepositoryCore.h"

#ifdef TEST_REPOSITORYCORE

int main() {
	std::cout << "Building Repository Core";
	return 0;
}
#endif // TEST_REPOSITORYCORE

